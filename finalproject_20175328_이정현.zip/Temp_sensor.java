package project;

import java.util.List;

import org.ws4d.coap.core.enumerations.CoapMediaType;
import org.ws4d.coap.core.rest.BasicCoapResource;
import org.ws4d.coap.core.rest.CoapData;
import org.ws4d.coap.core.tools.Encoder;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;

import week3.DHT11;
import week4.PIR_sensor;

public class Temp_sensor extends BasicCoapResource{
	
	static GpioController gpio = GpioFactory.getInstance();
	static GpioPinDigitalOutput r_led = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_08,PinState.LOW);
	static GpioPinDigitalOutput g_led = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_09,PinState.LOW);
	public static GpioPinDigitalInput pir = gpio.provisionDigitalInputPin(RaspiPin.GPIO_15);
	private String value="0"; 
	//DHT11 dht = new DHT11();
	
	public static boolean sensor = false;
	
	private Temp_sensor(String path, String value, CoapMediaType mediaType) {
		super(path, value, mediaType);
		
	}

	public Temp_sensor() {
		this("/temperature", "0", CoapMediaType.text_plain);
	}
	
	@Override
	public synchronized CoapData get(List<CoapMediaType> mediaTypesAccepted) {
		//float[] sensing_data = dht.getTemperature(15);
		//this.value = Float.toString(sensing_data[1]);
		return new CoapData(Encoder.StringToByte(this.value), CoapMediaType.text_plain);
	}

	
	@Override
	public synchronized boolean setValue(byte[] value) {
		this.value = Encoder.ByteToString(value);
		return true;
	}
	public synchronized void optional_changed() {
		boolean PIR_result = false;
		
		while(true) {
			PIR_result = pir.isHigh();
			if(PIR_result) {
				System.out.println("Detected!");
				r_led.high();
				g_led.low();
			}
			else {
				System.out.println("Not Detected!");
				r_led.low();
				g_led.high();
			}
		}
	}
	
	@Override
	public synchronized boolean post(byte[] data, CoapMediaType type) {
		return this.setValue(data);
	}

	@Override
	public synchronized boolean put(byte[] data, CoapMediaType type) {
		return this.setValue(data);
	}

	@Override
	public synchronized String getResourceType() {
		return "Raspberry pi 4 Temperature Sensor";
	}
}
